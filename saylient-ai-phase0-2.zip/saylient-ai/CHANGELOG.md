# Changelog
All notable changes are documented here. Format: Keep a Changelog, versioning: SemVer.

## [Unreleased]
### Added
- Initial project documentation (PRD, architecture, security, roadmap).
- Phase 0–2 (2026-11-13, staging only — not pushed): FastAPI baseline in
  `apps/api` (rule-based engine `prototype-0.1` ported from the live repo,
  LLM provider adapter Gemini/Groq with rule-based fallback, `POST
  /v1/suggest` + `POST /v1/analyze`, 48 pytest tests); `docs/LLM_CHOICE.md`;
  `ml/data/seed.jsonl` (60 examples, 6 per scenario) + stratified 80/10/10
  splits; `ml/evaluation/metrics.py`; `ml/training/train_qlora.py`
  (Qwen2.5-3B-Instruct QLoRA, NOT RUN — needs Colab T4 + full dataset).
  Web app and extension are placeholders (`apps/web/NOTE.md`,
  `apps/extension/NOTE.md`) until Phases 4–5.
