# Extension Specification (Chrome, Manifest V3)

## 1. Purpose
Let freelancers get reply suggestions from any conversation page with one shortcut, in a side panel, without opening a new tab.

## 2. Manifest essentials
```json
{
  "manifest_version": 3,
  "name": "SaylientAI",
  "version": "0.1.0",
  "permissions": ["activeTab", "scripting", "sidePanel", "storage", "identity"],
  "host_permissions": ["https://api.saylient.example/*"],
  "background": {"service_worker": "background.js", "type": "module"},
  "side_panel": {"default_path": "sidepanel.html"},
  "commands": {
    "open-saylient": {
      "suggested_key": {"default": "Ctrl+Shift+S", "mac": "Command+Shift+S"},
      "description": "Open SaylientAI side panel"
    }
  },
  "action": {"default_title": "SaylientAI"},
  "content_security_policy": {"extension_pages": "script-src 'self'; object-src 'self'"}
}
```
No `<all_urls>`. Backend domain only.

## 3. Behavior
1. Shortcut (or toolbar click) -> service worker calls `chrome.sidePanel.open()` (requires user gesture).
2. Panel asks service worker to inject the extractor into the active tab via `chrome.scripting.executeScript` (on demand).
3. Extractor returns, in priority order: user text selection, else the last N messages in known chat containers (Gmail, LinkedIn, Upwork, Fiverr, WhatsApp Web), else visible text.
4. Panel shows the extracted text (editable) with a "Clear" button and a note: "This text will be sent to SaylientAI".
5. Redactor masks emails, phones, card/IBAN, CNIC patterns locally.
6. Panel calls `/v1/suggest`; renders tone chips, 3 reply cards, explanation, score.
7. Actions: Copy, Insert into compose box (confirm first), Regenerate, Feedback.

## 4. Authentication
`chrome.identity.launchWebAuthFlow` against the web app login; short-lived access token stored in `chrome.storage.session`. Refresh via the web session; no long-lived secrets in the extension.

## 5. Rules
- Never read page text in the background or on page load.
- Skip `input[type=password]`, payment fields and hidden elements.
- Render extracted text with `textContent`.
- No remote code, no eval.
- Handle failures: offline, 401 (re-login), 429 (cool-down message), 503 (model unavailable).

## 6. Performance
Side panel opens < 1 s; extraction < 300 ms; show skeleton while generating.

## 7. Publishing
Developer-mode package for evaluation; unlisted Chrome Web Store listing later. Provide a privacy disclosure and single-purpose description.
