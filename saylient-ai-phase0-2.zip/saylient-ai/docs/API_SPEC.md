# API Specification (v1)

Base URL: `/v1` | Format: JSON | Auth: `Authorization: Bearer <access_token>` unless noted.
Machine-readable version: `openapi.yaml`.

## Conventions
- Errors: `{"error": {"code": "string", "message": "string"}}`
- Rate limit headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`
- Max body size: 16 KB. Max message length: 4,000 chars.

## Auth
| Method | Path | Description |
|---|---|---|
| POST | `/auth/register` | `{email, password}` -> 201, sends verification email |
| POST | `/auth/verify-email` | `{token}` -> 200 |
| POST | `/auth/login` | `{email, password}` -> access token + refresh cookie |
| POST | `/auth/refresh` | rotates refresh token (httpOnly cookie) |
| POST | `/auth/logout` | revokes refresh token |
| POST | `/auth/reset-password` | request/confirm password reset |
| POST | `/auth/extension-token` | short-lived token for the extension |

## Core
### POST `/analyze`
Request: `{"text": "string", "goal": "string?"}`
Response:
```json
{"scenario": "late_payment", "face_threat": "high", "detected_strategy": "bald_on_record", "issues": ["too direct"]}
```

### POST `/suggest`
Request:
```json
{"text": "Client hasn't paid for 12 days", "tone": "polite", "goal": "ask for payment", "context": {"relationship": "regular_client"}}
```
Response:
```json
{
  "scenario": "late_payment",
  "strategy": "negative_politeness",
  "replies": [{"tone": "polite", "text": "..."}, {"tone": "friendly", "text": "..."}, {"tone": "firm", "text": "..."}],
  "explanation": "Hedged request reduces imposition while keeping the deadline clear.",
  "score": 91,
  "model_version": "saylient-v0.1",
  "suggestion_id": "uuid"
}
```

## User data
| Method | Path | Description |
|---|---|---|
| GET | `/history` | list (only if history enabled) |
| DELETE | `/history/{id}` | delete one item |
| DELETE | `/history` | delete all |
| GET/PUT | `/settings` | `save_history`, `default_tone`, `language` |
| POST | `/feedback` | `{suggestion_id, rating, reason?}` |
| GET | `/export` | download all user data |
| DELETE | `/account` | delete account and data |

## System
`GET /health` returns `{"status": "ok"}` (no auth).

## Status codes
200 OK, 201 Created, 400 validation error, 401 unauthenticated, 403 forbidden, 404 not found, 413 payload too large, 429 rate limited, 503 model unavailable.
