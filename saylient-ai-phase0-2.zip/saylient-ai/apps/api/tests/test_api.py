"""HTTP endpoint tests (no LLM key configured in this environment, so
``POST /v1/suggest`` is exercised on its rule-based fallback path;
the LLM paths are covered in ``test_llm_client.py`` / ``test_suggest.py``).
"""

from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app, raise_server_exceptions=False)


def test_health_reports_llm_disabled() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["llm_enabled"] is False
    assert body["llm_provider"] == "none"
    assert response.headers["X-Request-Id"]


def test_suggest_falls_back_to_rule_engine_without_key() -> None:
    response = client.post(
        "/v1/suggest",
        json={
            "message": "The invoice #1048 is two weeks overdue. When will I be paid?",
            "goal": "request_payment",
            "context": {"power": "unknown", "social_distance": "medium", "imposition": "high"},
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["source"] == "rule_based"
    assert body["llm_status"] == "disabled"
    assert body["scenario"] == "late_payment"
    assert body["intent"] == "request_payment"
    assert body["replies"] and "#1048" in body["replies"][0]
    assert 0 <= body["score"] <= 100


def test_analyze_is_rule_engine_only() -> None:
    response = client.post(
        "/v1/analyze",
        json={
            "message": "Could we move the deadline to Friday?",
            "goal": "negotiate_deadline",
            "context": {"power": "unknown", "social_distance": "medium", "imposition": "medium"},
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["source"] == "rule_based"
    assert body["intent"]["label"] == "negotiate_deadline"
    assert body["strategy"]["label"] == "negative_politeness"
    assert body["model_version"] == "prototype-0.1"
    assert body["draft"]
    assert body["limitations"]


def test_suggest_rejects_empty_message() -> None:
    response = client.post("/v1/suggest", json={"message": "", "goal": "request_payment"})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "VALIDATION_ERROR"


def test_suggest_rejects_unknown_goal() -> None:
    response = client.post(
        "/v1/suggest", json={"message": "Hello.", "goal": "win_the_lottery"}
    )
    assert response.status_code == 422


def test_analyze_requires_a_goal() -> None:
    response = client.post("/v1/analyze", json={"message": "Hello."})
    assert response.status_code == 422


def test_oversized_body_is_413() -> None:
    response = client.post(
        "/v1/suggest",
        json={"message": "x" * (1_048_577), "goal": "request_payment"},
    )
    assert response.status_code == 413
    assert response.json()["error"]["code"] == "TOO_LARGE"


def test_unknown_route_uses_the_error_envelope() -> None:
    response = client.get("/v1/nope")
    assert response.status_code == 404
    body = response.json()
    assert body["error"]["code"] == "NOT_FOUND"
    assert body["error"]["request_id"]
    assert response.headers["X-Request-Id"]


def test_security_headers_present() -> None:
    response = client.get("/health")
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
