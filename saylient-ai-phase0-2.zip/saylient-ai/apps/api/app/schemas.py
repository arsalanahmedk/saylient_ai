"""Typed request/response schemas for the Phase 0-2 API (FastAPI + Pydantic v2).

Validation is authoritative on the server:
- ``message`` is 1-2000 chars; ``goal`` must be one of the 7 intents
  (the rule engine's taxonomy, from the live repo);
- P/D/R values are from {unknown, low, medium, high} and are never
  inferred from the message text;
- ``scenario`` (when the LLM answers) is one of the 10 plan scenarios.

The response contract for ``POST /v1/suggest`` is the plan's contract
(``docs/API_SPEC.md``): ``scenario``, ``strategy``, ``replies[]``,
``explanation``, ``score`` — plus ``source`` / ``llm_status`` so the
caller always knows whether the answer came from the LLM or from the
rule-based fallback, and ``intent`` so the rule engine's label is never
lost in the scenario mapping.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

ContextLevel = Literal["unknown", "low", "medium", "high"]

# The 7 intents of the rule-based engine (live repo, prototype-0.1).
GOALS = (
    "set_boundary",
    "request_payment",
    "negotiate_deadline",
    "clarify_requirements",
    "respond_to_criticism",
    "negotiate_budget",
    "resolve_disagreement",
)

# The 10 scenarios of the FYP plan (docs/DATASET_SPEC.md §10.1).
SCENARIOS = (
    "late_payment",
    "deadline_extension",
    "scope_creep",
    "revision_limit",
    "low-budget_offer",
    "ghosting_follow_up",
    "rude_client",
    "refund_demand",
    "boundary_setting",
    "compliment_negotiation",
)

# Brown & Levinson (1987) strategy labels used across the project.
STRATEGIES = (
    "bald_on_record",
    "positive_politeness",
    "negative_politeness",
    "off_record",
    "avoidance",
)

TONES = ("polite", "friendly", "firm", "formal")
ENGINE_TONES = ("Professional", "Friendly", "Diplomatic", "Assertive", "Empathetic")
DIRECTNESS_OPTIONS = ("direct", "balanced", "gentle")


class ContextFactors(BaseModel):
    power: ContextLevel = "unknown"
    social_distance: ContextLevel = "unknown"
    imposition: ContextLevel = "unknown"


class SuggestRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    goal: str | None = Field(default=None, description="One of the 7 intents; optional hint.")
    context: ContextFactors = Field(default_factory=ContextFactors)
    tone: str = Field(default="polite", description="polite | friendly | firm | formal")
    directness: str = Field(default="balanced", description="direct | balanced | gentle")

    def model_post_init(self, __context) -> None:  # noqa: ANN001, ANN202
        if self.goal is not None and self.goal not in GOALS:
            raise ValueError(f"goal must be one of {', '.join(GOALS)}.")
        if self.tone not in TONES:
            raise ValueError(f"tone must be one of {', '.join(TONES)}.")
        if self.directness not in DIRECTNESS_OPTIONS:
            raise ValueError(
                f"directness must be one of {', '.join(DIRECTNESS_OPTIONS)}."
            )


class AnalyzeRequest(BaseModel):
    """Same input as /v1/suggest; answered by the rule engine only."""

    message: str = Field(..., min_length=1, max_length=2000)
    goal: str = Field(..., description="One of the 7 intents.")
    context: ContextFactors = Field(default_factory=ContextFactors)
    tone: str = Field(default="Diplomatic")
    directness: str = Field(default="balanced")

    def model_post_init(self, __context) -> None:  # noqa: ANN001, ANN202
        if self.goal not in GOALS:
            raise ValueError(f"goal must be one of {', '.join(GOALS)}.")
        if self.tone not in ENGINE_TONES:
            raise ValueError(f"tone must be one of {', '.join(ENGINE_TONES)}.")
        if self.directness not in DIRECTNESS_OPTIONS:
            raise ValueError(
                f"directness must be one of {', '.join(DIRECTNESS_OPTIONS)}."
            )


class SuggestResponse(BaseModel):
    scenario: str
    intent: str
    strategy: str
    strategy_rationale: str
    replies: list[str]
    explanation: str
    score: float = Field(..., ge=0, le=100, description="Rule-based politeness score, 0-100.")
    llm_score: float | None = Field(
        default=None, description="Score the LLM itself reported, if any."
    )
    source: str = Field(..., description="'llm' or 'rule_based'.")
    llm_status: str = Field(
        ...,
        description="ok | disabled | rate_limited | invalid_response | blocked_injection | error",
    )
    model_version: str
    limitations: list[str] = Field(default_factory=list)


class AnalyzeResponse(BaseModel):
    """The rule engine's output contract, verbatim (prototype-0.1)."""

    intent: dict
    tone: dict
    fta: dict
    face_concern: list[str]
    context_factors: ContextFactors
    strategy: dict
    draft: str
    limitations: list[str]
    model_version: str
    source: str = "rule_based"
