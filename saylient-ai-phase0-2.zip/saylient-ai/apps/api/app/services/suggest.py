"""Suggestion orchestration: LLM first, rule-based engine as fallback.

``POST /v1/suggest`` always returns a useful answer:

1. If an LLM provider is configured, ask it (see ``llm_client``).
2. On **any** LLM failure — no key, 429 quota/rate-limit, timeout,
   invalid JSON after the repair retry, blocked injection — fall back to
   the rule-based engine (``prototype-0.1``) and say so in the response
   (``source="rule_based"`` + ``llm_status``). The user never sees an
   LLM error as their error.
3. The rule engine's draft becomes the single reply; its intent is
   mapped to the plan's 10-scenario taxonomy (best effort — the engine
   speaks 7 intents, the plan speaks 10 scenarios, and the original
   ``intent`` label is always returned alongside ``scenario``).

``POST /v1/analyze`` is rule-engine-only by design (deterministic,
no external call, no key needed) — it is the evaluation baseline.
"""

from __future__ import annotations

import logging

from app.core.config import Settings, get_settings
from app.schemas import AnalyzeResponse, ContextFactors, SuggestResponse
from app.services import analysis_engine
from app.services.llm_client import (
    LLMBlocked,
    LLMDisabled,
    LLMError,
    LLMInvalidResponse,
    LLMOutput,
    LLMRateLimited,
    LLMClient,
)
from app.services.politeness import politeness_score

logger = logging.getLogger("saylient.suggest")

# Best-effort mapping from the engine's 7 intents to the plan's 10
# scenarios. Where an intent spans two scenarios the message text
# decides (scope/extra/revision wording -> scope_creep, otherwise the
# boundary default). Documented here because it is a judgement call,
# not a fact the engine asserts.
_SCOPE_WORDS = ("scope", "extra", "revision", "revisions", "additional")


def intent_to_scenario(intent: str, message: str) -> str:
    lowered = message.lower()
    mapping = {
        "request_payment": "late_payment",
        "negotiate_deadline": "deadline_extension",
        "negotiate_budget": "low-budget_offer",
        "respond_to_criticism": "rude_client",
        "resolve_disagreement": "rude_client",
        "clarify_requirements": "scope_creep",
    }
    if intent == "set_boundary":
        return (
            "scope_creep"
            if any(word in lowered for word in _SCOPE_WORDS)
            else "boundary_setting"
        )
    return mapping.get(intent, "boundary_setting")


# The engine's draft tones are Professional/Friendly/Diplomatic/
# Assertive/Empathetic; the suggest API takes polite/friendly/firm/formal.
_TONE_MAP = {
    "polite": "Diplomatic",
    "friendly": "Friendly",
    "firm": "Assertive",
    "formal": "Professional",
}


def _rule_based_suggestion(
    *, message: str, goal: str | None, context: ContextFactors,
    tone: str, directness: str, llm_status: str,
) -> SuggestResponse:
    """Build a SuggestResponse from the rule-based engine."""
    engine_tone = _TONE_MAP.get(tone, "Diplomatic")
    result = analysis_engine.analyze(
        message,
        goal or "set_boundary",
        context.model_dump(),
        draft_tone=engine_tone,
        draft_directness=directness,
    )
    intent = result["intent"]["label"]
    draft = result["draft"]
    return SuggestResponse(
        scenario=intent_to_scenario(intent, message),
        intent=intent,
        strategy=result["strategy"]["label"],
        strategy_rationale=result["strategy"]["rationale"],
        replies=[draft],
        explanation=(
            "Rule-based baseline reply (prototype-0.1): "
            f"{result['strategy']['rationale']}"
        ),
        score=politeness_score(draft),
        llm_score=None,
        source="rule_based",
        llm_status=llm_status,
        model_version=analysis_engine.MODEL_VERSION,
        limitations=result["limitations"],
    )


def _llm_suggestion(output: LLMOutput, *, intent: str) -> SuggestResponse:
    """Build a SuggestResponse from a validated LLM answer."""
    score = politeness_score(output.replies[0])
    return SuggestResponse(
        scenario=output.scenario,
        intent=intent,
        strategy=output.strategy,
        strategy_rationale=output.explanation,
        replies=output.replies,
        explanation=output.explanation,
        score=score,
        llm_score=output.score,
        source="llm",
        llm_status="ok",
        model_version="llm",
        limitations=[
            "LLM-generated reply: check it before sending; it may not "
            "match the client's exact situation."
        ],
    )


def suggest(
    *,
    message: str,
    goal: str | None = None,
    context: ContextFactors | None = None,
    tone: str = "polite",
    directness: str = "balanced",
    settings: Settings | None = None,
    llm_client: LLMClient | None = None,
) -> SuggestResponse:
    """Return a suggestion, LLM-first with rule-based fallback."""
    settings = settings or get_settings()
    context = context or ContextFactors()
    client = llm_client or LLMClient(settings)

    # The rule engine's intent (cheap, deterministic) is used as the
    # ``intent`` label in both paths, so LLM and fallback answers are
    # comparable in evaluation.
    try:
        engine_intent = analysis_engine.analyze(
            message, goal or "set_boundary", context.model_dump()
        )["intent"]["label"]
    except ValueError:
        engine_intent = "unknown"

    try:
        output = client.generate(message=message, goal=goal, tone=tone)
    except LLMDisabled:
        logger.info("LLM disabled (no provider/key); using rule-based engine.")
        return _rule_based_suggestion(
            message=message, goal=goal, context=context, tone=tone,
            directness=directness, llm_status="disabled",
        )
    except LLMBlocked as exc:
        logger.warning("LLM blocked by injection guardrail: %s", exc.reason)
        return _rule_based_suggestion(
            message=message, goal=goal, context=context, tone=tone,
            directness=directness, llm_status="blocked_injection",
        )
    except LLMRateLimited:
        logger.warning("LLM rate-limited (429); using rule-based engine.")
        return _rule_based_suggestion(
            message=message, goal=goal, context=context, tone=tone,
            directness=directness, llm_status="rate_limited",
        )
    except LLMInvalidResponse:
        logger.warning("LLM returned invalid JSON twice; using rule-based engine.")
        return _rule_based_suggestion(
            message=message, goal=goal, context=context, tone=tone,
            directness=directness, llm_status="invalid_response",
        )
    except LLMError as exc:
        logger.warning("LLM error (%s); using rule-based engine.", exc)
        return _rule_based_suggestion(
            message=message, goal=goal, context=context, tone=tone,
            directness=directness, llm_status="error",
        )

    return _llm_suggestion(output, intent=engine_intent)


def analyze(
    *,
    message: str,
    goal: str,
    context: ContextFactors | None = None,
    tone: str = "Diplomatic",
    directness: str = "balanced",
) -> AnalyzeResponse:
    """Rule-engine-only analysis (deterministic baseline, no LLM call)."""
    context = context or ContextFactors()
    result = analysis_engine.analyze(
        message,
        goal,
        context.model_dump(),
        draft_tone=tone,
        draft_directness=directness,
    )
    return AnalyzeResponse(
        intent=result["intent"],
        tone=result["tone"],
        fta=result["fta"],
        face_concern=result["face_concern"],
        context_factors=ContextFactors(**result["context_factors"]),
        strategy=result["strategy"],
        draft=result["draft"],
        limitations=result["limitations"],
        model_version=result["model_version"],
    )
